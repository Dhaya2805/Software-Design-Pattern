import React from 'react'
import '../styles/AdminDash.css';
const AdminDash = () => {
  return (
    <div className='headder-admin-h1'>
      <h1>Hello Admin</h1>
    </div>
  )
}

export default AdminDash
